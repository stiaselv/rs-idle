package com.stian;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RsIdleApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
